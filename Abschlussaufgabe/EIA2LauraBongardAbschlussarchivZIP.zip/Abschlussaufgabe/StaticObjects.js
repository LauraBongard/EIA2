/*
Aufgabe: Abschlussaufgabe
Name: Laura Bongard
Matrikel: 256028
Datum: 20.02.18
    
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
*/
var Abschlussaufgabe;
(function (Abschlussaufgabe) {
    class StaticObjects {
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
        draw() { }
    }
    Abschlussaufgabe.StaticObjects = StaticObjects;
})(Abschlussaufgabe || (Abschlussaufgabe = {}));
//# sourceMappingURL=StaticObjects.js.map